<template>
  <div style="padding:30px;">
    <el-alert :closable="false" title="active_scan" type="success">
      <router-view />
    </el-alert>
  </div>
</template>
